package Data;
import java.sql.Statement;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;

public class DBContext {
    private String JDBC_URL = "jdbc:postgresql://localhost:5432/petshop";
    private String JDBC_USER = "postgres";
    private String JDBC_PASSWORD = "123";

    public Connection connection = null;

    public DBContext() {

    }

    public void conectarBanco(){
        try{
            this.connection = DriverManager.getConnection(this.JDBC_URL, this.JDBC_USER, this.JDBC_PASSWORD);
        } catch (Exception e){
            e.printStackTrace();
        }
    }

    public void desconectarBanco(){
        try {
            this.connection.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public ResultSet executarQuerySql(String query){
        try {
            Statement stmt = this.connection.createStatement();

            ResultSet resultSet = stmt.executeQuery(query);
            return resultSet;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    public boolean executarUpdateSql(String query){
        try {
            Statement stmt = this.connection.createStatement();
            stmt.executeUpdate(query);
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
}
